package io.curity.identityserver.plugin.GoogleLdapLink

import com.unboundid.ldap.sdk.*
import de.mkammerer.argon2.Argon2Advanced
import de.mkammerer.argon2.Argon2Factory
import org.slf4j.LoggerFactory
import se.curity.identityserver.sdk.attribute.Attribute
import se.curity.identityserver.sdk.attribute.Attributes
import se.curity.identityserver.sdk.attribute.AuthenticationAttributes
import se.curity.identityserver.sdk.attribute.SubjectAttributes
import se.curity.identityserver.sdk.authenticationaction.AuthenticationAction
import se.curity.identityserver.sdk.authenticationaction.AuthenticationActionContext
import se.curity.identityserver.sdk.authenticationaction.AuthenticationActionResult
import java.security.SecureRandom

class GoogleLdapLinkAuthenticationAction(
    private val config: GoogleLdapLinkAuthenticationActionConfig
) : AuthenticationAction {

    private val logger = LoggerFactory.getLogger(GoogleLdapLinkAuthenticationAction::class.java)
    private val argon2: Argon2Advanced = Argon2Factory.createAdvanced(Argon2Factory.Argon2Types.ARGON2id)

    companion object {
        private const val ARGON2_ITERATIONS  = 3
        private const val ARGON2_MEMORY      = 65536
        private const val ARGON2_PARALLELISM = 4
        private const val GOOGLE_ID_ATTR     = "googleId"
        private const val GOOGLE_SALT_ATTR   = "googleIdSalt"
        private const val GOOGLE_OC          = "googleIdentity"
    }

    override fun apply(context: AuthenticationActionContext): AuthenticationActionResult {

        val authAttributes    = context.authenticationAttributes
        val subjectAttributes = authAttributes.subjectAttributes

        val googleSub = subjectAttributes.get("subject")?.attributeValue?.value as? String
        val email     = subjectAttributes.get("email")?.attributeValue?.value as? String

        if (googleSub == null || email == null) {
            logger.warn("Google sub of email ontbreekt — controleer de 'email' scope op de Google authenticator")
            return AuthenticationActionResult.failedResult("Ontbrekende Google claims")
        }

        logger.debug("Google LDAP koppeling gestart voor: {}", email)

        return try {
            val conn = openLdapConnection()

            // Controleer of Google sub al gekoppeld is
            val existingDn = findUserByHashedSub(conn, googleSub)
            val userDn = if (existingDn != null) {
                logger.info("Google sub al gekoppeld aan: {}", existingDn)
                existingDn
            } else {
                // Zoek user via email
                val foundDn = findUserByEmail(conn, email)
                if (foundDn == null) {
                    logger.warn("Geen LDAP account gevonden voor: {}", email)
                    conn.close()
                    return AuthenticationActionResult.failedResult(
                        "Geen LDAP account gevonden voor dit Google account")
                }

                // Hash en sla op
                val externalSalt = generateExternalSalt()
                val pepper       = System.getenv(config.getPepperEnvVar())
                    ?: throw IllegalStateException("Environment variabele ${config.getPepperEnvVar()} niet gevonden")
                val pepperedSub  = "${googleSub}${pepper}${externalSalt}"
                val hashedSub    = argon2.hash(
                    ARGON2_ITERATIONS, ARGON2_MEMORY, ARGON2_PARALLELISM,
                    pepperedSub.toCharArray())

                writeHashedSubToLdap(conn, foundDn, hashedSub, externalSalt)
                logger.info("Google sub gehasht (Argon2id) en gekoppeld aan: {}", foundDn)
                foundDn
            }

            // Haal LDAP uid op voor subject replacement
            val ldapEntry = conn.getEntry(userDn, "uid", "mail", "cn")
            conn.close()

            val ldapUid = ldapEntry?.getAttributeValue("uid")
            if (ldapUid == null) {
                logger.error("Geen uid gevonden in LDAP voor DN: {}", userDn)
                return AuthenticationActionResult.failedResult("Interne fout bij account koppeling")
            }

            logger.info("Subject vervangen: Google sub → LDAP uid '{}'", ldapUid)

            // Vervang de Google subject door de lokale LDAP uid
            val newSubjectAttributes = SubjectAttributes.of(
                ldapUid,
                Attributes.of(
                    Attribute.of("uid", ldapUid),
                    Attribute.of("email", email)
                )
            )

            val newAuthAttributes = AuthenticationAttributes.of(
                newSubjectAttributes,
                authAttributes.contextAttributes
            )
            AuthenticationActionResult.successfulResult(newAuthAttributes)

        } catch (e: LDAPException) {
            logger.error("LDAP fout: {}", e.message)
            AuthenticationActionResult.failedResult("Interne fout bij account koppeling")
        }
    }

    private fun openLdapConnection(): LDAPConnection {
    val ldapPassword = System.getenv(config.getLdapAdminPasswordEnvVar())
        ?: throw IllegalStateException("Environment variabele ${config.getLdapAdminPasswordEnvVar()} niet gevonden")
    val conn = LDAPConnection(config.getLdapHost(), config.getLdapPort())
    conn.bind(config.getLdapAdminDn(), ldapPassword)
    return conn
    }

    private fun findUserByEmail(conn: LDAPConnection, email: String): String? {
        val filter = Filter.createEqualityFilter("mail", email)
        val result = conn.search(config.getLdapBaseDn(), SearchScope.ONE, filter, "dn")
        return result.searchEntries.firstOrNull()?.dn
    }

    private fun findUserByHashedSub(conn: LDAPConnection, googleSub: String): String? {
        val filter = Filter.createPresenceFilter(GOOGLE_ID_ATTR)
        val result = conn.search(
            config.getLdapBaseDn(), SearchScope.ONE, filter,
            "dn", GOOGLE_ID_ATTR, GOOGLE_SALT_ATTR)
        val pepper = System.getenv(config.getPepperEnvVar())
            ?: throw IllegalStateException("Environment variabele ${config.getPepperEnvVar()} niet gevonden")


        for (entry in result.searchEntries) {
            val storedHash = entry.getAttributeValue(GOOGLE_ID_ATTR) ?: continue
            val storedSalt = entry.getAttributeValue(GOOGLE_SALT_ATTR) ?: continue
            val pepperedSub = "${googleSub}${pepper}${storedSalt}"
            if (argon2.verify(storedHash, pepperedSub.toCharArray())) return entry.dn
        }
        return null
    }

    private fun writeHashedSubToLdap(
        conn: LDAPConnection, userDn: String,
        hashedSub: String, externalSalt: String
    ) {
        val entry = conn.getEntry(userDn, "objectClass")
            ?: throw LDAPException(ResultCode.NO_SUCH_OBJECT, "Entry niet gevonden: $userDn")

        val currentClasses = entry.getAttributeValues("objectClass")?.toList() ?: emptyList()
        val mods = mutableListOf<Modification>()

        if (!currentClasses.contains(GOOGLE_OC)) {
            mods.add(Modification(ModificationType.ADD, "objectClass", GOOGLE_OC))
        }
        mods.add(Modification(ModificationType.ADD, GOOGLE_ID_ATTR, hashedSub))
        mods.add(Modification(ModificationType.ADD, GOOGLE_SALT_ATTR, externalSalt))
        conn.modify(userDn, mods)
    }

    private fun generateExternalSalt(): String {
        val random = SecureRandom()
        val bytes  = ByteArray(32)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }
}