package io.curity.identityserver.plugin.GoogleLdapLink

import se.curity.identityserver.sdk.config.Configuration
import se.curity.identityserver.sdk.config.annotation.Description

interface GoogleLdapLinkAuthenticationActionConfig : Configuration {

    @Description("OpenLDAP hostname binnen het cluster, bijv. openldap-service")
    fun getLdapHost(): String

    @Description("OpenLDAP poort (standaard 389)")
    fun getLdapPort(): Int

    @Description("LDAP admin DN, bijv. cn=admin,dc=camazotz,dc=me")
    fun getLdapAdminDn(): String

    @Description("Naam van de environment variabele die het LDAP wachtwoord bevat, bijv. LDAP_ADMIN_PASSWORD")
    fun getLdapAdminPasswordEnvVar(): String

    @Description("Naam van de environment variabele die de pepper bevat, bijv. GOOGLE_LDAP_PEPPER")
    fun getPepperEnvVar(): String

    @Description("LDAP base DN, bijv. ou=people,dc=camazotz,dc=me")
    fun getLdapBaseDn(): String
}