package io.curity.identityserver.plugin.GoogleLdapLink

import se.curity.identityserver.sdk.authenticationaction.AuthenticationAction
import se.curity.identityserver.sdk.plugin.descriptor.AuthenticationActionPluginDescriptor

class GoogleLdapLinkAuthenticationActionPluginDescriptor :
    AuthenticationActionPluginDescriptor<GoogleLdapLinkAuthenticationActionConfig> {

    override fun getPluginImplementationType(): String = "google-ldap-link"

    override fun getConfigurationType(): Class<out GoogleLdapLinkAuthenticationActionConfig> =
        GoogleLdapLinkAuthenticationActionConfig::class.java

    override fun getAuthenticationAction(): Class<out AuthenticationAction> =
        GoogleLdapLinkAuthenticationAction::class.java
}
